document.addEventListener('DOMContentLoaded', function() {
    const categorySelect = document.getElementById('category');
    const productSelect = document.getElementById('product');
    const attributeSelect = document.getElementById('attribute');

    categorySelect.addEventListener('change', function() {
        const categoryId = this.value;
        fetchProducts(categoryId);
    });

    productSelect.addEventListener('change', function() {
        const productId = this.value;
        fetchAttributes(productId);
    });

    function fetchProducts(categoryId) {
        fetch(baseUri + 'module/ns_quotation/ajax?action=getProducts&category_id=' + categoryId)
            .then(response => response.json())
            .then(data => {
                populateSelect(productSelect, data.products);
                productSelect.disabled = false;
            });
    }

    function fetchAttributes(productId) {
        fetch(baseUri + 'module/ns_quotation/ajax?action=getAttributes&product_id=' + productId)
            .then(response => response.json())
            .then(data => {
                populateSelect(attributeSelect, data.attributes);
                attributeSelect.disabled = false;
            });
    }

    function populateSelect(selectElement, items) {
        selectElement.innerHTML = '<option value="">Select an option</option>';
        items.forEach(item => {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = item.name;
            selectElement.appendChild(option);
        });
    }
});
