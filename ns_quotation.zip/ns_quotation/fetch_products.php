<?php
include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../init.php');

$context = Context::getContext();
$id_lang=$context->language->id;

$categoryId = (int)Tools::getValue('category_id');
$products = Product::getProducts($context->language->id, 0, 0, 'name', 'ASC', $categoryId);

$html = '<label for="product">Select Product</label>';
$html .= '<div class="product-selection">';
foreach ($products as $product) {
    $productObj = new Product($product['id_product']);
    $image = Image::getCover($productObj->id);
    $imageUrl = $context->link->getImageLink($productObj->link_rewrite[$id_lang], $image['id_image'], 'home_default');
    
    $html .= '<div class="product-item" id="product_item_' . $product['id_product'] . '"  onclick="handleProductClick('.$product['id_product'].')">';	

    $html .= '<input type="radio" name="product" id="product_' . $product['id_product'] . '" value="' . $product['id_product'] . '" onchange="fetchAttributes(this.value)">';
    $html .= '<label for="product_' . $product['id_product'] . '">';
    $html .= '<img src="' . $imageUrl . '" alt="' . $product['name'] . '" class="product-image">';
    $html .= '<span class="product-name">' . $product['name'] . '</span>';
    $html .= '</label>';
    $html .= '</div>';
}
$html .= '</div>';

// JavaScript to handle the click event and change style
$html .= '';

echo $html;
?>

