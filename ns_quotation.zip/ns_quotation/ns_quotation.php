<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class Ns_Quotation extends Module
{
    public function __construct()
    {
        $this->name = 'ns_quotation';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'NdiagaSoft';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('NS Quotation');
        $this->description = $this->l('Allows customers to request a quotation for products.');

        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
    }

    public function install()
    {
        return parent::install() &&
            $this->registerHook('displayHome') &&
            $this->registerHook('displayHeader') &&
            $this->installDb();
    }

    public function uninstall()
    {
        return parent::uninstall() &&
            $this->uninstallDb();
    }

    private function installDb()
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ns_quotation` (
            `id_quotation` INT(11) NOT NULL AUTO_INCREMENT,
            `id_product` INT(11) NOT NULL,
			`id_category` INT(11) NOT NULL,
            `id_customer` INT(11) DEFAULT NULL,            
			`attributes` TEXT NOT NULL,
			`price` float,
			`comment` TEXT,
            `quantity` INT(11) NOT NULL,
            `status` VARCHAR(255) NOT NULL DEFAULT "Pending",
            `date_add` DATETIME NOT NULL,
            PRIMARY KEY (`id_quotation`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';

        return Db::getInstance()->execute($sql);
    }

    private function uninstallDb()
    {
        $sql = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'ns_quotation`';
        return Db::getInstance()->execute($sql);
    }
	
	
	private function installAdminTabs()
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = 'AdminQuotation';
        $tab->name = array_fill_keys(Language::getLanguages(false), 'Quotations');
        $tab->id_parent = (int)Tab::getIdFromClassName('AdminParentOrders');
        $tab->module = $this->name;
        return $tab->add();
    }

    private function uninstallAdminTabs()
    {
        $id_tab = (int)Tab::getIdFromClassName('AdminQuotation');
        if ($id_tab) {
            $tab = new Tab($id_tab);
            return $tab->delete();
        }
        return true;
    }

    public function hookDisplayHome($params)
	{
		// Fetch categories
		$categories = Category::getCategories($this->context->language->id, true, false);
		$base_dir_nka = Tools::getHttpHost(true).__PS_BASE_URI__;

		// Assign categories to Smarty template
		$this->context->smarty->assign('categories', $categories);
		$this->context->smarty->assign('base_dir_nka', $base_dir_nka);

		// Display the template
		return $this->display(__FILE__, 'views/templates/hook/quotation_form.tpl');
	}

    public function hookDisplayHeader($params)
    {
        $this->context->controller->registerStylesheet(
            'module-ns-quotation-style',
            'modules/'.$this->name.'/views/css/quotation.css',
            ['media' => 'all', 'priority' => 150]
        );
        /*
        $this->context->controller->registerJavascript(
            'module-ns-quotation-js',
            'modules/'.$this->name.'/views/js/quotation.js',
            ['position' => 'bottom', 'priority' => 150]
        );
		*/
    }

    public function getContent()
    {
           
		   $this->postProcess(); 
		   
		   if (Tools::isSubmit('action') && Tools::getValue('action') == 'provideQuote') {
             return $this->renderProvideQuoteForm((int)Tools::getValue('id_quotation'));
           }
		   
		   
		   
		    $output=$this->display(__FILE__, 'advertizement.tpl');
		
			return $this->renderAdminForm().'<br>'.$output;
    }
	

	private function deleteQuote($idQuotation)
	{
		Db::getInstance()->delete('ns_quotation', 'id_quotation = ' . (int)$idQuotation);
	}


    private function renderAdminForm()
    {
        $quotations = $this->getQuotations();

        $this->context->smarty->assign('quotations', $quotations);
		$this->context->smarty->assign('link', $this->context->link);
		$nka_link=$this->context->link->getAdminLink('AdminModules', false);

        $this->smarty->assign([
            'admin_link'=>$nka_link,
            'token'=>Tools::getAdminTokenLite('AdminModules'),
            'module_name'=>$this->name,
        ]);

		

        return $this->display(__FILE__, 'views/templates/admin/quotations.tpl');
    }

   private function getQuotations()
	{
		$sql = 'SELECT q.*, p.name as product_name, i.id_image, c.firstname, c.lastname
				FROM ' . _DB_PREFIX_ . 'ns_quotation q
				LEFT JOIN ' . _DB_PREFIX_ . 'product_lang p ON (q.id_product = p.id_product AND p.id_lang = ' . (int)$this->context->language->id . ')
				LEFT JOIN ' . _DB_PREFIX_ . 'image i ON (q.id_product = i.id_product AND i.cover = 1)
				LEFT JOIN ' . _DB_PREFIX_ . 'customer c ON (q.id_customer = c.id_customer)
				ORDER BY q.date_add DESC';
		return Db::getInstance()->executeS($sql);
	}

	
	
	public function sendQuote($categoryId,$productId,$attributeString,$quantity)
	{		
					
			$customer = $this->context->customer;
				  // Save the quotation (for example, save to a database or send an email)
			$context = Context::getContext();
			$customerId = $context->customer->id;
			Db::getInstance()->insert('ns_quotation', [
				'id_product' => $productId,
				'id_customer' => $customerId,
				'attributes' => pSQL($attributeString),
				'quantity' => $quantity,
				'date_add' => date('Y-m-d H:i:s')
			]);

			// Send email notification to admin
			$adminEmail = Configuration::get('PS_SHOP_EMAIL');
			Mail::Send(
				$context->language->id,
				'new_quotation',
				'New Quotation Request',
				[
					'{product_id}' => $productId,
					'{attributes}' => $attributeString,
					'{quantity}' => $quantity
				],
				$adminEmail,
				null,
				$customer->firstname,
				$customer->email,
				null,
				null,
				dirname(__FILE__).'/mails/'
			);
		
	}
	
	


	private function renderProvideQuoteForm($idQuotation)
	{
		$quotation = $this->getQuotationById($idQuotation);
		
		$token=Tools::getAdminTokenLite('AdminModules');

		if (!$quotation) {
			return '<p>' . $this->l('Quotation not found') . '</p>';
		}

		$html = '<form action="' .$this->context->link->getAdminLink('AdminModules', false). '&configure='.$this->name.'&token='.$token.'" method="post">';
		$html .= '<input type="hidden" name="id_quotation" value="' . $idQuotation . '">';
		$html .= '<div class="form-group">';
		$html .= '<label for="price">' . $this->l('Price') . '</label>';
		$html .= '<input type="text" name="price" id="price" class="form-control" required>';
		$html .= '</div>';
		$html .= '<div class="form-group">';
		$html .= '<label for="comment">' . $this->l('Comment') . '</label>';
		$html .= '<textarea name="comment" id="comment" class="form-control" required></textarea>';
		$html .= '</div>';
		$html .= '<button type="submit" name="submit_quote" class="btn btn-primary">' . $this->l('Save') . '</button>';
		$html .= '</form>';

		return $html;
	}

	private function getQuotationById($idQuotation)
	{
    $sql = 'SELECT * FROM '._DB_PREFIX_.'ns_quotation WHERE id_quotation = '.(int)$idQuotation;
    return Db::getInstance()->getRow($sql);
	}

	
	
	  public function postProcess()
{
    if (Tools::isSubmit('bulk_delete')) {
        $quoteIds = Tools::getValue('quote_ids');
        if (!empty($quoteIds) && is_array($quoteIds)) {
            foreach ($quoteIds as $idQuotation) {
                $this->deleteQuote((int)$idQuotation);
            }
            $this->context->controller->confirmations[] = $this->l('Selected quotes have been deleted.');
        }
    }

    if (Tools::isSubmit('submit_quote')) {
        $idQuotation = (int)Tools::getValue('id_quotation');
        $price = (float)Tools::getValue('price');
        $comment = Tools::getValue('comment');
        $this->saveQuote($idQuotation, $price, $comment);
        $this->sendQuoteEmail($idQuotation, $price, $comment);
        $this->context->controller->confirmations[] = $this->l('Quote has been provided.');
    }
}

	private function saveQuote($idQuotation, $price, $comment)
	{
		Db::getInstance()->update('ns_quotation', [
			'price' => (float)$price,
			'comment' => pSQL($comment),
			'status' => 'provided'
		], 'id_quotation = ' . (int)$idQuotation);
	}

	private function sendQuoteEmail($idQuotation, $price, $comment)
	{
		$quotation = $this->getQuotationById($idQuotation);
		$customer = new Customer((int)$quotation['id_customer']);
		$product = new Product((int)$quotation['id_product'], false, $this->context->language->id);

		$templateVars = [
			'{firstname}' => $customer->firstname,
			'{lastname}' => $customer->lastname,
			'{product_name}' => $product->name,
			'{price}' => Tools::displayPrice($price),
			'{comment}' => $comment
		];

		Mail::Send(
			$this->context->language->id,
			'quotation_provided',
			$this->l('Your Quotation Request'),
			$templateVars,
			$customer->email,
			$customer->firstname . ' ' . $customer->lastname,
			null,
			null,
			null,
			null,
			_PS_MODULE_DIR_ . $this->name . '/mails/',
			false,
			$this->context->shop->id
		);
	}

		
	
}
