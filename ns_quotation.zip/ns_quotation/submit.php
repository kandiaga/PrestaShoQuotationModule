<?php
include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../init.php');
include(dirname(__FILE__).'/ns_quotation.php');

$context = Context::getContext();

$categoryId = (int)Tools::getValue('category');
$productId = (int)Tools::getValue('product');
$quantity = (int)Tools::getValue('quantity');

$selectedAttributes = Tools::getValue('attributes');

// Prepare the attribute string
$attributeString = '';
foreach ($selectedAttributes as $group => $attribute) {
    $attributeString .= $group . ' - ' . $attribute . ', ';
}
$attributeString = rtrim($attributeString, ', ');

$module = Module::getInstanceByName('ns_quotation');
$module->sendQuote($categoryId, $productId, $attributeString, $quantity);

// Set a success message parameter
Tools::redirect($context->link->getPageLink('index', true, null, ['quote_success' => 1]));
?>
