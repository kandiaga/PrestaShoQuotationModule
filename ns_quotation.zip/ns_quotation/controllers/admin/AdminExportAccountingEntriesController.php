<?php

require_once _PS_MODULE_DIR_ . 'ns_accounting/classes/AccountingEntry.php';

class AdminExportAccountingEntriesController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function initContent()
    {
        parent::initContent();
        $this->context->smarty->assign([
            'export_link' => $this->context->link->getAdminLink('AdminExportAccountingEntries').'&export=1'
        ]);
        $this->setTemplate('export.tpl');
    }

    public function postProcess()
    {
        if (Tools::isSubmit('export')) {
            $this->processExport();
        }
    }

    protected function processExport()
    {
        $entries = AccountingEntry::getAllEntries();

        $filename = 'accounting_entries_'.date('Y-m-d_H-i-s').'.csv';
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        $output = fopen('php://output', 'w');

        fputcsv($output, ['ID', 'Date', 'Account', 'Description', 'Debit', 'Credit']);

        foreach ($entries as $entry) {
            fputcsv($output, [
                $entry['id_entry'],
                $entry['date_add'],
                $entry['account'],
                $entry['description'],
                $entry['debit'],
                $entry['credit']
            ]);
        }

        fclose($output);
        exit;
    }
}
