<?php
include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../init.php');

$context = Context::getContext();
$productId = (int)Tools::getValue('product_id');
$product = new Product($productId);

// Get product attributes
$attributes = $product->getAttributeCombinations($context->language->id);

// Organize attributes by group
$attributeGroups = [];
foreach ($attributes as $attribute) {
    $groupId = $attribute['id_attribute_group'];
    if (!isset($attributeGroups[$groupId])) {
        $attributeGroups[$groupId] = [
            'name' => $attribute['group_name'],
            'attributes' => []
        ];
    }
    $attributeGroups[$groupId]['attributes'][] = [
        'id' => $attribute['id_attribute'],
        'name' => $attribute['attribute_name']
    ];
}

// Generate HTML
//$html = '<form id="quotationForm" method="POST" action="submit_quotation.php">';

$html='';

foreach ($attributeGroups as $group) {
    $html .= '<label for="group_' . $group['name'] . '">' . $group['name'] . '</label>';
    $html .= '<select name="attributes[' . $group['name'] . ']" id="group_' . $group['name'] . '" class="form-control">';
    foreach ($group['attributes'] as $attribute) {
        $html .= '<option value="' . $attribute['name'] . '">' . $attribute['name'] . '</option>';
    }
    $html .= '</select>';
}
/*
$html .= '<label for="quantity">Quantity</label>';
$html .= '<input type="number" name="quantity" id="quantity" class="form-control" min="1" required>';
$html .= '<input type="hidden" name="product_id" value="' . $productId . '">';
$html .= '<button type="submit" class="btn btn-primary">Submit</button>';
$html .= '</form>';

*/

echo $html;
?>
